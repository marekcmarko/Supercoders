/*
 *
 *    JS TABS
 *
 */
let items = [];
const buttons = document.querySelectorAll('button');
const wrapper = document.querySelector('section.products');


buttons.forEach(function (button) {
  button.addEventListener('click',event => {
    changeCategoryItems(event.target.dataset.category);
  });
});

function createItem(item) {
  return `

  <div class="product__img">
    <img src="${item.img}" class="">
  </div>

  <div class="product__name _tc">
    <h4 class="">${item.heading}</h4>
  </div>

  <div class="text-desc product__desc">
    <p class="">${item.description}</p>
  </div>


  <div class="product__bottom-content">
    <span class="product__info">${item.info}</span>
    <a href="" role="button" class="btn btn--teal btn--animated product__btn">${item.btn}</a>
  </div>

  `
}

function changeCategoryItems(categoryId) {
    const viewItems = (categoryId == 0 ) ? items : items.filter(item => item.category == categoryId);
    wrapper.innerHTML = "";
    viewItems.forEach(item => {
      const div = document.createElement('div');
      div.setAttribute("class", "product");
      div.innerHTML = createItem(item);
      wrapper.appendChild(div);
    });
};

fetch('https://api.myjson.com/bins/olmwa')
.then(function (res) { return res.json() })
.then(function (data) {
  items = data.items;
  changeCategoryItems(1);
});

/*
 *
 *    CUSTOM.JS
 *
 */

(function($){

  // STICKY //

    function sticky() {

      var sticky_point = $(".header").height() + 20;

          $(window).scroll(function(e){

              if ($(window).scrollTop() > sticky_point && $(window).width() > 600) {

                  $("#panel").addClass("header-sticky-open");

                  $("#progress-bar").show();

                  var height = document.body.scrollTop || document.documentElement.scrollTop;
                  var width = document.documentElement.scrollHeight - document.documentElement.clientHeight;
                  var scrolled = (height / width) * 100;
                  document.getElementById("progress-bar").style.width = scrolled + "%";

              } 
              else {
                  $("#panel").removeClass("header-sticky-open");

                  $("#progress-bar").hide();
              }
          });
    }


  $(document).ready(function(){

    // STICKY //
    if ($("header").hasClass("sticky-header")) {
      sticky();
    }

  });


  // SLIDING LIST TABS

  var lists = document.querySelectorAll('.js-filter-list .filter__tab');

  lists.forEach(function (list) {
      list.addEventListener('click', function (e) {
          e.preventDefault();
          if (this.classList.contains('active')) {
              return;
          }
          for (var i = 0; i < lists.length; i++) {
              lists[i].classList.remove('active')
          }
          this.classList.add('active')
      })
  })

  // SCROLL TO ANCHOR

  $('a[href^="#"]').on('click', function(e) {
    e.preventDefault();

    var target = this.hash;
    var $target = $(target);

    $('html, body').animate({
      'scrollTop': $target.offset().top -50
    }, 800, 'swing');
  });


})(window.jQuery);